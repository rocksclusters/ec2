.. ref-ses

===
SES
===


boto.ses
------------

.. automodule:: boto.ses
   :members:   
   :undoc-members:

boto.ses.connection
---------------------

.. automodule:: boto.ses.connection
   :members:   
   :undoc-members:

