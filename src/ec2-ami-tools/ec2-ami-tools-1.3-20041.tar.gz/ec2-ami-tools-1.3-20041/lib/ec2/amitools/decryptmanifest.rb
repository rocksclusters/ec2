require 'ec2/amitools/crypto'

USAGE = "Usage: decryptmanifest private-key-path"

if ARGV.size < 1
  puts USAGE
  exit 1
end

puts Crypto::decryptasym( $stdin.read, ARGV[0] )
