require 'ec2/amitools/bundlemachineparameters'

# The Bundle Image command line parameters.
class BundleImageParameters < BundleMachineParameters

  IMAGE_PATH_DESCRIPTION = "The path to the file system image to bundle."
  PREFIX_DESCRIPTION = "The filename prefix for bundled AMI files. Defaults to image name."

  attr_reader :image_path
  attr_reader :prefix
                
  def initialize( argv, name )
    add_mandatory_parameters_proc = lambda do
      on( '-i', '--image PATH', String, IMAGE_PATH_DESCRIPTION ) do |p|
        unless p and File::exist?( p )
          raise "the specified image file #{p} does not exist"
        end
        @image_path = p
      end
    end
    
    add_optional_parameters_proc = lambda do
      on( '-p', '--prefix PREFIX', String, PREFIX_DESCRIPTION ) do |p|
        @prefix = p
      end
    end
    
    super(argv, name, add_mandatory_parameters_proc, add_optional_parameters_proc)
  end
end
