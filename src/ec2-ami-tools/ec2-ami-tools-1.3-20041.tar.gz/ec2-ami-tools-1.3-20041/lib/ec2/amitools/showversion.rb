#!/usr/bin/env ruby
require 'ec2/amitools/version'
puts "#{PKG_VERSION}-#{PKG_RELEASE} #{MANIFEST_VERSION}"

