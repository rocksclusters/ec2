
require 'ec2/amitools/fileutil'
require 'ec2/platform/current'

module SysChecks
  def self.rsync_usable?()
    EC2::Platform::Current::Rsync.usable?
  end
  def self.good_tar_version?()
    EC2::Platform::Current::Tar::Version.current.usable?
  end
  def self.get_system_arch()
    EC2::Platform::Current::System::BUNDLING_ARCHITECTURE
  end
  def self.root_user?()
    EC2::Platform::Current::System.superuser?
  end
end
