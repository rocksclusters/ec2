##
# An exception thrown to indicate an unrecoverable error has been encountered.
# The process should be terminated and the exception's message should be
# displayed to the user.
#
class FatalError < Exception
  ##
  # ((|message|)) The message that should be displayed to the user.
  # ((|cause|))  The exception that caused the fatal error.
  #
  def initialize(message, cause = nil)
    super(message)
    @cause = cause
  end
end

#------------------------------------------------------------------------------#

##
# File access error.
#
class FileError < FatalError
  def initialize(filename, error_description, sys_call_err = nil)
      message = "File Error: #{error_description} \n" +
                "File name: #{filename}\n"
      super(message, sys_call_err)
  end
end

#------------------------------------------------------------------------------#

##
# Directory access exception.
#
class DirectoryError < FatalError
  def initialize(dirname, error_description, sys_call_err = nil)
    message =	"Directory Error: #{error_description} \n" +
                "Directory name: #{dirname} \n"
    super(message, sys_call_error)
  end
end

#----------------------------------------------------------------------------#

class DownloadError < FatalError
  def initialize(resource, addr, port, path, error=nil)
    super("could not download #{resource} from #{addr}/#{path} on #{port}", error)
  end
end

#----------------------------------------------------------------------------#

class UploadError < FatalError
  def initialize(resource, addr, port, path, error=nil)
    super("could not upload #{resource} to #{addr}/#{path} on #{port}", error)
  end
end

#------------------------------------------------------------------------------#

##
# Parameter error.
#
class ParameterError < FatalError
  def initialize(message)
    super(message)
  end
end

#------------------------------------------------------------------------------#

class AMIInvalid < FatalError
  def initialize(message)
    super(message)
  end
end