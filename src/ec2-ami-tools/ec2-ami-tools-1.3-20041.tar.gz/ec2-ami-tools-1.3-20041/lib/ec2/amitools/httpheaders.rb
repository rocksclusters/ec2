require 'ec2/amitools/crypto'
require 'base64'
require 'set'
require 'time'

class HttpHeaders
  MANDATORY = Set.new( [ 'content-md5', 'content-type', 'date' ] )
  X_AMZ_PREFIX = 'x-amz'
  
  def initialize
    @headers = {}
  end
  
  # Add a header with _name_ and _value_.
  def add( name, value )
    raise ArgumentError.new( "name must be a String" ) unless name.respond_to? :downcase
    raise ArgumentError.new( "value must be a String" ) unless value.respond_to? :downcase
    @headers[name.downcase.strip] = value.downcase.strip
  end
  
  # Sign the headers using HMAC SHA1. The _http_verb_ e.g. GET, PUT
  # DELETE is used as part of the signature so must be supplied.
  def sign( aws_access_key_id, aws_secret_access_key, http_verb, resource_path )
    #
    # Add the http Date header.
    #

    @headers['date'] = Time.now.httpdate
    
    #
    # Build the data to sign.
    #
    data = http_verb + "\n"
    
    #
    # Add new lines for content-type and content-md5 if not present.
    #
    data += "\n" unless @headers.include?( 'content-type' )
    data += "\n" unless @headers.include?( 'content-md5' )
    
    #
    # Add mandatory headers and those that start with the x-amz prefix.
    #
    @headers.sort.each do |name, value|
      if MANDATORY.include?( name ) 
        data += value + "\n"
      end
      
      # Headers that start with x-amz must have both their name and value added.
      if name =~ /^#{X_AMZ_PREFIX}/
        data += name + ":" + value +"\n"
      end
    end
    
    data += resource_path
    
    #
    # Sign headers and then put signature back into headers.
    #
    signature = Base64.encode64( Crypto::hmac_sha1( aws_secret_access_key, data ) )
    signature.chomp!
    @headers['Authorization'] = "AWS #{aws_access_key_id}:#{signature}"
  end
  
  # Return the headers as a map from header name to header value.
  def get
    return @headers.clone
  end
  
  # Return the headers as curl arguments of the form "-H name:value".
  def curl_arguments
    args = ''
    @headers.each do |name, value|
      args += curl_argument( name, value ) + ' '
    end
    return args
  end
  
  # Return the header as a curl argument of the form "-H name:value".
  def curl_argument( name, value )
    return "-H \"#{name}:#{value}\""
  end
end
