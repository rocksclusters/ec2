#!/usr/bin/ruby

require 'ec2/amitools/util'
require 'yaml'

EXT2 = 'ext2'
EXT3 = 'ext3'

##
# Make FC4 Image creates a file system image and installs Fedora Core 4
# Base onto it.
#
# This script largely follow the Fedora Xen Quickstart guide at
# http://www.fedoraproject.org/wiki/FedoraXenQuickstart
#
# The steps to make an FC 4 image are:
# 1) Create a sparse image file.
# 2) Mount image file as loopback device filesystem.
# 3) Format the image using specified filesystem type.
# 4) Make necessary device nodes on the image.
# 5) Mount a dummy proc filesystem in the image.
# 6) Install Fedora Core 4 Base into the image.
# 7) Copy across configuration files that aren't created during a chrooted yum
#    install.
# 8) Unmount the image.
#
class MakeFC4Image
  IMG_MNT = '/tmp/mnt'      # The mount point for the image.
  INSTALL_DIR = '/usr/local/aes/amiutil/'
  FSTAB_FILE = INSTALL_DIR + 'config/fstab'
  HOSTS_FILE = INSTALL_DIR + 'config/hosts'
  YUM_CONF_FILE = INSTALL_DIR + 'config/yum.conf'
  YUM = 'yum -c ' + YUM_CONF_FILE +
        ' --disablerepo=extras --disablerepo=updates-released ' +
        '--installroot=' + IMG_MNT + ' -y '
  APP_NAME = 'Make FC4 Image'

  #----------------------------------------------------------------------------#

  ##
  # ((|cfg|)) The configuration to use.
  #
  def initialize(cfg)
    @cfg = cfg
    @log = Log
    @image_filename = File.join(@cfg.destination, @cfg.name + '.img')
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Run the image building process.  
  #
  def run
    begin
      @log.println("#{APP_NAME} started with configuration:")
      @log.print(@cfg.to_s)
      create_image_file
      format_image
      mount_image
      make_device_nodes
      make_fstab
      mount_proc
      install_base
      install_fedora_rpms
      install_cfg_files
      install_network_file
      disable_selinux
      install_rpms

      @log.println("#{APP_NAME} completed.")
    rescue Exception => e
      @log.error("#{APP_NAME} failed.", e)
      raise e
    ensure
      unmount_proc
      unmount_image
    end
  end
  
  private
  
  #----------------------------------------------------------------------------#
  
  ##
  # Create blank image file.
  #
  def create_image_file
    begin
      task = "create " + @cfg.image_size_mb.to_s + " MB image file " + @image_filename
      @log.task_start(task)
      exec("dd if=/dev/zero of=" + @image_filename + " bs=1M count=1 seek=" + @cfg.image_size_mb.to_s)
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#

  ##
  # Execut the specified command in a shell.
  #
  def exec(cmd)
    system(cmd)
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Format the image.
  #
  def format_image
    begin
      task = 'format image with ' + @cfg.fs_type.to_s + ' filesystem'
      @log.task_start(task)
      
      # Determine command to use from configured filesystem type.
      if (!@cfg.fs_type) then
        raise "No filesystem type specified"
      elsif (@cfg.fs_type == EXT2) then
        cmd = '/sbin/mke2fs -F '
      elsif (@cfg.fs_type == EXT3) then
        cmd = '/sbin/mkfs.ext3 -F '
      else
        raise "Unsupported filesystem type: " + @cfg.fs_type.to_s
      end
      
      # Create filesystem.
      exec(cmd + @image_filename)
      
      # Done.
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end
  
  #----------------------------------------------------------------------------#
  
  ##
  # Mount the image.
  #
  def mount_image
    begin
      @log.task_start(task = 'mount image')
      Dir.mkdir(IMG_MNT) if !FileTest.exists?(IMG_MNT)
      exec('sync') # Flush changes to file system.
      exec('mount -o loop ' + @image_filename + ' ' + IMG_MNT)
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Unmount the image.
  #
  def unmount_image
    exec('umount -d ' + IMG_MNT)
  end
  
  #----------------------------------------------------------------------------#
  
  ##
  # Unmount the proc filesystem in the image.
  #
  def unmount_proc
    system('umount -d ' + IMG_MNT + '/proc')
  end
  
  #----------------------------------------------------------------------------#
  
  ##
  # Make some device nodes because initrd is not being used yet.
  #
  def make_device_nodes
    begin
      @log.task_start(task = 'make device nodes')
      dev_dir = IMG_MNT + '/dev'
      Dir.mkdir(dev_dir) if !FileTest.exists?(dev_dir)
      exec('for i in console null zero ; do /sbin/MAKEDEV -d ' + dev_dir + ' -x $i ; done')
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Create a file system table.
  #
  def make_fstab
    begin
      @log.task_start(task = 'make fstab')
      exec('mkdir ' + IMG_MNT + '/etc')
      exec('cp ' + FSTAB_FILE + ' ' + IMG_MNT + '/etc')
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Mount a dummy proc filesystem within the image.
  #
  def mount_proc
    begin
      @log.task_start(task = 'mount proc')
      proc_dir = IMG_MNT + '/proc'
      exec('mkdir ' + proc_dir) if !FileTest.exists?(proc_dir)
      exec('mount -t proc none ' + proc_dir)
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Install Fedora base onto image.
  #
  def install_base
    begin
      @log.task_start(task = 'install base to image ' + @image_filename)
      exec(YUM + ' groupinstall Base')
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Install configuration files. Because the yum install is chrooted, certain
  # post install scripts fail. This method fixes that.
  #
  def install_cfg_files
    begin
      @log.task_start(task = 'install configuration files')
      exec('cp ' + HOSTS_FILE + ' ' + IMG_MNT + '/etc')
      exec('cp ' + FSTAB_FILE + ' '+ IMG_MNT + '/etc')
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#

  def install_network_file
    begin
      @log.task_start(task = 'install /etc/sysconfig/network')
      File.open("#{IMG_MNT}/etc/sysconfig/network", 'w') do |f|
        f.write("NETWORKING=yes\n")
        f.write("HOSTNAME=#{@cfg.name}")
      end
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Install Fedora RPMS
  #
  def install_fedora_rpms
    begin
      @log.task_start(task = 'install Fedora RPMs to image ' + @image_filename)  
      @cfg.fedora_rpms.each {|rpm| install_fedora_rpm(rpm)}
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#

  ##
  # Install a Fedora rpm and any dependencies using Yum.
  #
  def install_fedora_rpm(rpm_name)
    @log.action('install RPM ' + rpm_name)
    if not exec(YUM + ' install ' + rpm_name) then
      raise "yum install of Fedora Core 4 Base failed"
    end
  end

  #----------------------------------------------------------------------------#

  ##
  # Install specified non-Fedora RPMS.
  #
  def install_rpms
    begin
      @log.task_start(task = 'install miscellaneous RPMs to image ' + @image_filename)
      @cfg.rpm_urls.each {|rpm_url| install_rpm(rpm_url)} if @cfg.rpm_urls
      @log.task_complete(task)
    rescue
      @log.task_failed(task)
      raise
    end
  end

  #----------------------------------------------------------------------------#

  ##
  # Install the specified rpm.
  #
  def install_rpm(rpm_uri)
    @log.action('install RPM ' + rpm_uri)
    exec('rpm -i --root ' + IMG_MNT + ' ' + rpm_uri)
  end

  #----------------------------------------------------------------------------#
  
  ##
  # Disable SELinux
  #
  def disable_selinux
    cfgfile = File.join(IMG_MNT, '/etc/selinux/config')
    lines = File.open(cfgfile, File::RDONLY) {|file| file.readlines}
    lines.each do |line|
      line.replace("SELINUX=disabled\n") if line.strip === 'SELINUX=enforcing'
    end
    File.open(cfgfile, File::TRUNC | File::WRONLY){|file| file.write(lines.join)}
  end
end

#------------------------------------------------------------------------------#

##
# The make-fc4-image configuration.
#
class Configuration
  attr_reader :fedora_rpms    # List of Fedora RPM file base names.
  attr_reader :rpm_urls       # List of URLs to non-Fedora RPM files.
  attr_reader :name           # The image name.
  attr_reader :destination    # The destnation for the generated DomU files.
  attr_reader :image_size_mb  # Image size in MB.
  attr_reader :mnt_path       # Target mount path for the image.
  attr_reader :fs_type        # File system type.
  
  attr_writer :fedora_rpms
  attr_writer :rpm_urls
  attr_writer :name
  attr_writer :destination
  attr_writer :image_size_mb
  attr_writer :mnt_path
  attr_writer :fs_type
  
  #----------------------------------------------------------------------------#

  def to_s
    to_yaml + "\n"
  end
end

#------------------------------------------------------------------------------#

##
# Run the image build process.
#
def main
  # Get and verify parameters.
  if ARGV.size < 1 then
    puts 'make-fc4-domu <configuration file>'
    exit 1
  end
  
  # Check configuration file exists.
  if not FileTest.exists?(ARGV[0]) then
    puts 'Could not find specified configuration file: ' + ARGV[0]
    exit 1 
  end
    
  # Run make domu.
  begin
  File.open(ARGV[0]) do |f|
    MakeFC4Image.new(YAML::load(f)).run
  end
  rescue Exception => e
    puts e.backtrace
  end
end

#------------------------------------------------------------------------------#

##
# Print a sample configuration to stdout.
#
def output_example_cfg
  cfg = Configuration.new
  cfg.name = 'test-domu'
  cfg.destination = '/tmp'
  cfg.image_size_mb = 1024
  cfg.fs_type = EXT3
  cfg.fedora_rpms = ['ruby-1.8.2-7.i386.rpm', 'ruby-libs-1.8.2-7.i386.rpm']
  cfg.rpm_urls = ['http://ns1/repo/fedora/core/4/i386/os/Fedora/RPMS/ruby-devel-1.8.2-7.i386.rpm']
  $stdout.write(cfg.to_yaml)
end

#------------------------------------------------------------------------------#

##
# Entry point.
#
main
#output_example_cfg
