require 'ec2/amitools/bundlemachineparameters'

# The Bundle Volume command line parameters.
class BundleVolParameters < BundleMachineParameters
  
  PREFIX_DESCRIPTION = "The filename prefix for bundled AMI files. Defaults to \"image\"."
  EXCLUDE_DESCRIPTION= ["A comma-separated list of absolute directory paths to exclude. This",
                        "option overrides the \"--all\" option."]
  ALL_DESCRIPTION    = ["Include all directories in the volume being bundled, including those",
                        "on remotely mounted filesystems."]
  SIZE_DESCRIPTION   = ["The size, in MB (1024 * 1024 bytes), of the image file to create.",
                        "The maximum size is 10240 MB."]
  VOLUME_DESCRIPTION = "The absolute path to the mounted volume to be bundled. Defaults to \"/\"."
  FSTAB_DESCRIPTION  = "The absolute path to the fstab to be bundled into the image."
  INHERIT_DESCRIPTION= ['Inherit instance metadata. Enabled by default.',
                        'Bundling will fail if inherit is enabled but instance data',
                        'is not accessible, for example not bundling an EC2 instance.']
  
  attr_accessor :all,
                :exclude,
                :prefix,
                :size,
                :volume,
                :fstab,
                :inherit

  class Error < RuntimeError
    class InvalidExcludedDirectory < Error
      def initialize( dir )
        super( "invalid excluded directory: #{dir}" )
      end
    end
  end
  
  def initialize( argv, name )    
    #
    # Function to add optional parameters. This will be run by the
    # parent class's initializer.
    #
      
    @inherit = true
      
    add_optional_params_proc = lambda do
      on( '-a', '--all', *BundleVolParameters::ALL_DESCRIPTION ) do
        @all = true
      end
      
      on( '-e', '--exclude DIR1,DIR2,...', Array, *BundleVolParameters::EXCLUDE_DESCRIPTION ) do |p|
        @exclude = p
      end
      
      on( '-p', '--prefix PREFIX', String, PREFIX_DESCRIPTION ) do |p|
        @prefix = p
      end
      
      on( '-s', '--size MB', Integer,  *BundleVolParameters::SIZE_DESCRIPTION) do |p|
        @size = p
      end
      
      on( '--[no-]inherit', INHERIT_DESCRIPTION ) do |p|
        @inherit = p
      end
      
      on( '-v', '--volume PATH', String, VOLUME_DESCRIPTION ) do |volume|
        unless volume and File::exist?( volume ) and File::directory?( volume )
          raise Error::InvalidValue.new( 'volume', volume )
        end
        @volume = volume
      end
      
      on( '--fstab PATH', String, FSTAB_DESCRIPTION ) do |fstab|
        unless fstab and File::exist?( fstab ) and not File::directory?( fstab )
          raise Error::InvalidValue.new( 'fstab', fstab )
        end
        @fstab = fstab
      end
    end
    
    super( argv, name, nil, add_optional_params_proc )
    
    #
    # Set defaults for optional parameters.
    #
    @exclude = [] unless @exclude
    @prefix = 'image' unless @prefix
    @size = MAX_SIZE_MB unless @size
    @volume = '/' unless @volume

    @fstab ||= :legacy if @arch == "i386"
    #
    # Verify parameters.
    #
    unless @show_help or @manual
      @exclude.each do |dir|
        path = File::join( @volume, dir )
        unless File::exist?( path ) and File::directory?( path )
          raise Error::InvalidExcludedDirectory.new( dir ) 
        end
      end
    end
  end
end
