require 'fileutils'
require 'tempfile'

require 'ec2/amitools/httpheaders'
require 'uri'

# Module that provides http functionality.
module HTTP
  class Error < RuntimeError
    class PathInvalid < Error
    end
    class Write < Error
    end
    class Transfer < Error
    end
    class Retrieve < Transfer
      attr_reader :http_response_code
      
      def initialize(msg, http_response_code=nil)
        super(msg)
        @http_response_code = http_response_code
      end
      
      def parse_http_response(str)
        # Look for somethin along the lines of '
        #   curl: (22) The requested URL returned error: 500
        m = /curl:\s+\(22\)\s+.*returned\s+error:\s+(\d\d\d)/.match(str)
        @http_response_code = m.captures[0].to_i if m
      end
    end
    class BadDigest < Error
    end
  end
  
  #----------------------------------------------------------------------------#
  
  # Save the file at _url_, to the local file at _path_.
  # The local file will be created if necessary, or overwritten if it already
  # exists. 
  def HTTP::get( url, path, user = nil, pass = nil, max_file_size = nil, expected_digest = nil )
    d = File.dirname(path)
    FileUtils.mkdir_p(d) unless File.exist?(d)
    
    if user and pass
      uri = URI.parse( url )
      headers = HttpHeaders.new
      headers.sign( user, pass, 'GET', uri.path )
      curl_arguments = headers.curl_arguments
    else
      curl_arguments = ""
    end
    
    if max_file_size
      curl_arguments += " --max-filesize #{max_file_size}"
    end
    
    tf = Tempfile.new('curling-iron')
    tf.close(false)
    
    begin
      cmd_line = "curl -f  #{curl_arguments} #{url} 2> #{tf.path} | tee #{path} | openssl sha1; exit ${PIPESTATUS[0]}"
      calculated_digest = IO.popen( cmd_line ) { |io| io.readline.chomp }
      
      unless $?.exitstatus == 0
        # @log.debug { "error executing #{cmd_line}"  }
        File::delete( path ) if File::exist?( path )
        raise case es = $?.exitstatus
              when 3 then Error::Transfer.new( "HTTP get failed: invalid url #{url}" )
              when 4 then Error::Transfer.new( "HTTP get failed: invalid url #{url}" )
              when 6 then Error::Transfer.new( "HTTP get failed: could not resolve hostname #{url}" )
              when 22 then 
                # 'man curl' claims
                # HTTP page not retrieved. The requested url was not found or returned another error with the HTTP error code being 400 or above.
                # This return code only appears if -f/--fail is used.
                # Let's try to extract the HTTP response code shall we?
                e = Error::Retrieve.new("HTTP get failed: file not found at #{url}")
                tf.open()
                e.parse_http_response(tf.read())
                tf.close(false)
                raise e
              when 23 then Error::Write.new( "HTTP get error: error writing file to local disk" )
              when 28 then Error::Transfer.new( "HTTP get error: curl timeout" )
              when 63 then Error::Transfer.new( "HTTP get failed: file exceeds maximum size of #{max_file_size}" )
              else Error::Transfer.new( "HTTP get failed: curl returned response code #{es}" ) end
      end
    ensure
      tf.close(true)
      FileUtils.rm_f(tf.path) if File.exist?(tf.path) # Yes, this is pointless
    end
    
    if expected_digest and expected_digest != calculated_digest
      File::delete( path ) if File::exist?( path )
      raise Error::BadDigest.new( "HTTP get failed: calculated digest #{calculated_digest} does not match expected digest #{expected_digest}")
    end
    
    return true
  end
  
  #----------------------------------------------------------------------------#
  
  # Put the file at _path_ to the _url_. The headers in the hash
  # _headers_ will be used. If _user_ and _password_ are supplied then the
  # headers will be signed.
  def HTTP::put( url, path, headers,  user = nil, pass = nil )
    raise Error::PathInvalid.new( path ) unless File::exist?( path )
    
    #
    # Set and sign the headers.
    #
    if user and pass
      uri = URI.parse( url )
      http_headers = HttpHeaders.new
      headers.each do |name, value| http_headers.add( name, value ) end
      http_headers.sign( user, pass, 'PUT', uri.path )
      curl_arguments = http_headers.curl_arguments
    else
      curl_arguments = ""
    end
        
    cmd_line = "curl -f -s #{curl_arguments} #{url} -T #{path}"
    system( cmd_line )
    
    unless $?.exitstatus == 0
      raise case es = $?.exitstatus
        when 3 then Error::Transfer.new( "HTTP put failed: invalid url #{url}" )
        when 4 then Error::Transfer.new( "HTTP put failed: invalid url #{url}" )
        when 6 then Error::Transfer.new( "HTTP put failed: could not resolve hostname #{url}" )
        when 28 then Error::Transfer.new( "HTTP put error: curl timeout" )  
        else Error::Transfer.new( "HTTP put failed: curl returned response code #{es}" ) end
    end
    
    return true
  end
  
  #----------------------------------------------------------------------------#
  
  # Delete the file at _url_.
  def HTTP::delete( url, user = nil, pass = nil )
    if user and pass
      uri = URI.parse( url )
      headers = HttpHeaders.new
      headers.sign( user, pass, 'DELETE', uri.path )
      curl_arguments = headers.curl_arguments
    else
      curl_arguments = ""
    end
    
    cmd_line = "curl -f -s -X DELETE #{curl_arguments} #{url}"
    # @log.info { "HTTP curl command line: #{cmd_line}" }
    retval = system( cmd_line )
    raise Error::Transfer.new( "delete failed for #{url}") unless retval
    retval
  end
end
