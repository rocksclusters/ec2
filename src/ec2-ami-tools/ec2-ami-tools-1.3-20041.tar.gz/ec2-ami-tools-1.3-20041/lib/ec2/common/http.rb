# ---------------------------------------------------------------------------
# Module that provides http functionality.
# ---------------------------------------------------------------------------
require 'uri'
require 'set'
require 'time'
require 'base64'
require 'tmpdir'
require 'tempfile'
require 'fileutils'

require 'ec2/common/curl'
require 'ec2/amitools/crypto'

module EC2
  module Common
    module HTTP
    
      class Response < EC2::Common::Curl::Response
        attr_reader :body
        def initialize(code, type, body=nil)
          super code, type
          @body = body
        end
      end
      
      class Headers
        MANDATORY = Set.new( [ 'content-md5', 'content-type', 'date' ] )
        X_AMZ_PREFIX = 'x-amz'
        
        def initialize(verb)
          raise ArgumentError.new('invalid verb') if verb.to_s.empty?
          @headers = {}
          @verb = verb
        end
        
        
        #---------------------------------------------------------------------
        # Add a Header key-value pair.        
        def add(name, value)
          raise ArgumentError.new( "name must be a String" ) unless name.is_a? String
          raise ArgumentError.new( "value must be a String" ) unless value.is_a? String
          @headers[name.downcase.strip] = value.downcase.strip
        end
        
        
        #-----------------------------------------------------------------------
        # Sign the headers using HMAC SHA1.
        def sign( aws_access_key_id, aws_secret_access_key, url )
      
          @headers['date'] = Time.now.httpdate          # add HTTP Date header
          
          # Build the data to sign.
          data = @verb + "\n"
          
          # Add new lines for content-type and content-md5 if not present.
          data += "\n" unless @headers.include?( 'content-type' )
          data += "\n" unless @headers.include?( 'content-md5' )          
          
          # Add mandatory headers and those that start with the x-amz prefix.
          @headers.sort.each do |name, value|
            if MANDATORY.include?( name )
              data += value + "\n"
            end
            
            # Headers that start with x-amz must have both their name and value 
            # added.
            if name =~ /^#{X_AMZ_PREFIX}/
              data += name + ":" + value +"\n"
            end
          end
          
          
          # Ignore everything in the URL after the question mark unless, by the
          # S3 protocol, it signifies an acl or torrent or logging parameter
          data << URI.parse(url).path
          ['acl', 'logging', 'torrent'].each do |item|
            regex = Regexp.new("[&?]#{item}($|&|=)")
            data << '?' + item if regex.match(url)
          end
          
          # Sign headers and then put signature back into headers.
          signature = Base64.encode64( Crypto::hmac_sha1( aws_secret_access_key, data ) )
          signature.chomp!
          @headers['Authorization'] = "AWS #{aws_access_key_id}:#{signature}"
        end
        
        
        #-----------------------------------------------------------------------
        # Return the headers as a map from header name to header value.
        def get
          return @headers.clone
        end
        
        
        #-----------------------------------------------------------------------
        # Return the headers as curl arguments of the form "-H name:value".
        def curl_arguments
          @headers.map { | name, value | "-H \"#{name}:#{value}\""}.join(' ')
        end
      end
    
    
      #-----------------------------------------------------------------------      
      # Errors.
      class Error < RuntimeError
        attr_reader :code
        def initialize(msg, code = nil)          
          super(msg)
          @code = code || 1
        end
        class PathInvalid < Error; end
        class Write < Error;       end
        class BadDigest < Error
          def initialize(file, expected, obtained)
            super("Digest for file '#{file}' #{obtained} differs from expected digest #{digest}")
          end
        end
        class Transfer < Error;    end
        class Retrieve < Transfer; end
      end
      
      
      #-----------------------------------------------------------------------      
      # Invoke curl with arguments given and process results of output file
      def HTTP::invoke( arguments, outfile, debug=false )
        begin
          raise ArgumentError.new(outfile) unless File.exists? outfile
          result = EC2::Common::Curl.execute(arguments, debug)
          if result.success?
            if result.response.success?
              return result.response
            else
              synopsis= 'Server.Error(' + result.response.code.to_s + '): '
              message = result.stderr + ' '
              if result.response.type == 'application/xml'                
                require 'rexml/document'
                doc = REXML::Document.new(IO.read(outfile))
                if doc.root
                  content = REXML::XPath.first(doc, '/Error/Code')
                  unless content.nil? or content.text.empty?
                    synopsis= 'Server.'+ content.text + '(' + 
                      result.response.code.to_s + '): '
                  end
                  content = REXML::XPath.first(doc, '/Error/Message')
                  message = content.text unless content.nil?
                end
              else
                if result.response.type =~ /text/
                  message << IO.read(outfile)
                end
              end
              raise Error::Transfer.new(synopsis + message, result.response.code)
            end
          else
            synopsis= 'Curl.Error(' + result.status.to_s + '): '
            message = result.stderr.split("\n").map { |line|            
              if (m = /^curl:\s+(?:\(\d{1,2}\)\s+)*(.*)$/.match(line) )
                (m.captures[0] == "try 'curl --help' for more information") ? 
                  '' : m.captures[0]
              else
                line.strip
              end
            }.join("\n")
            output = result.stdout.chomp
            if debug and not output.empty?
              message << "\nCurl.Output: " + output.gsub("\n", "\nCurl.Output: ")
            end
            raise Error::Transfer.new(synopsis + message.strip + '.', result.status)
          end
        rescue EC2::Common::Curl::Error => e
          raise Error::Transfer.new(e.message, e.code)
        end
      end
      
      #-----------------------------------------------------------------------      
      # Delete the file at the specified url.
      def HTTP::delete( url, options={}, user = nil, pass = nil, debug = false )
        raise ArgumentError.new('options') unless options.is_a? Hash
        begin
          output = Tempfile.new('ec2-delete-response')
          arguments = ['-X DELETE']
          
          headers = EC2::Common::HTTP::Headers.new( 'DELETE' )
          options.each do |name, value| headers.add( name, value ) end
          headers.sign( user, pass, url ) if user and pass
          arguments << headers.curl_arguments
          
          arguments << url
          arguments << '-o ' + output.path
          
          response = HTTP::invoke(arguments.join(' '), output.path, debug)
          return EC2::Common::HTTP::Response.new(response.code, response.type)
        ensure
          output.unlink
        end
      end
      
  
      #-----------------------------------------------------------------------      
      # Put the file at the specified path to the specified url. The content of
      # the options hash will be passed as HTTP headers. If the username and
      # password options are specified, then the headers will be signed.
      def HTTP::put( url, path, options={}, user = nil, pass = nil, debug = false )
        raise Error::PathInvalid.new( path ) unless path and File::exist?( path )
        raise ArgumentError.new('options') unless options.is_a? Hash
        
        begin
          output = Tempfile.new('ec2-put-response')        
          arguments = []
          
          headers = EC2::Common::HTTP::Headers.new('PUT')
          options.each do |name, value| headers.add( name, value ) end
          headers.sign( user, pass, url ) if user and pass
          arguments << headers.curl_arguments
          
          arguments << url
          arguments << '-T ' + path
          arguments << '-o ' + output.path
          
          response = HTTP::invoke(arguments.join(' '), output.path, debug)
          return EC2::Common::HTTP::Response.new(response.code, response.type)          
        ensure
          output.unlink
        end
      end
  
      #-----------------------------------------------------------------------      
      # Save the file at specified url, to the local file at specified path.
      # The local file will be created if necessary, or overwritten already
      # existing. If specified, the expected digest is compare to that of the
      # retrieved file which gets deleted if the calculated digest does not meet
      # expectations. If no path is specified, and the response is a 200 OK, the
      # content of the response will be returned as a String
      def HTTP::get( url, path=nil, options={}, user = nil, pass = nil, 
                    size = nil, digest = nil, debug = false )
        raise ArgumentError.new('options') unless options.is_a? Hash
        arguments = []
        buffer = nil
        if path.nil?
          buffer = Tempfile.new('ec2-get-response')
          path = buffer.path
        else
          directory = File.dirname(path)
          FileUtils.mkdir_p(directory) unless File.exist?(directory)
        end
       
        headers = EC2::Common::HTTP::Headers.new('GET')
        options.each do |name, value| headers.add( name, value ) end
        headers.sign( user, pass, url ) if user and pass
        arguments << headers.curl_arguments
        
        arguments << "--max-filesize #{size}" if size
        arguments << url
        arguments << '-o ' + path
        
        begin
          FileUtils.touch path
          response = HTTP::invoke(arguments.join(' '), path, debug)
          body = nil
          if response.success?
            if digest
              obtained = IO.popen("cat #{path} | openssl sha1") { |io| io.readline.chomp }
              unless digest == obtained                
                File.delete(path) if File.exists?(path)
                raise Error::BadDigest.new(path, expected, obtained)
              end
            end
            if buffer.is_a? Tempfile
              buffer.open; 
              body = buffer.read
              buffer.close
            end
          else
            File.delete( path ) if File.exist?( path )
          end
          return EC2::Common::HTTP::Response.new(response.code, response.type, body)
        rescue Error::Transfer => e
          File::delete( path ) if File::exist?( path )
          raise Error::Retrieve.new(e.message, e.code)
        ensure
          buffer.unlink if buffer.is_a? Tempfile and File.exists? buffer.path
        end
      end
      
  
      #-----------------------------------------------------------------------      
      # Get the HEAD response for the specified url.
      def HTTP::head( url, options={}, user = nil, pass = nil, debug = false )
        raise ArgumentError.new('options') unless options.is_a? Hash
        begin
          output = Tempfile.new('ec2-head-response')
          arguments = ['--head']
          
          headers = EC2::Common::HTTP::Headers.new('HEAD')
          options.each do |name, value| headers.add( name, value ) end
          headers.sign( user, pass, url ) if user and pass
          arguments << headers.curl_arguments
          
          arguments << url
          arguments << '-o ' + output.path
          
          response = HTTP::invoke(arguments.join(' '), output.path, debug)
          return EC2::Common::HTTP::Response.new(response.code, response.type)
          
        rescue Error::Transfer => e
          raise Error::Retrieve.new(e.message, e.code)
        ensure
          output.unlink
        end
      end
    end
  end
end