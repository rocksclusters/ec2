#------------------------------------------------------------------------------
require 'ec2/platform/base/pipeline'

#------------------------------------------------------------------------------
module EC2    
  #----------------------------------------------------------------------------
  module Platform
    #--------------------------------------------------------------------------
    module Linux
      #------------------------------------------------------------------------    
      class Pipeline < EC2::Platform::Base::Pipeline
        
        #----------------------------------------------------------------------
        # Given a pipeline of commands, modify it so that we can obtain
        # the exit status of each pipeline stage by reading the tempfile
        # associated with that stage. 
        def pipestatus(cmd)
          command = cmd
          command << ';' unless cmd.rstrip[-1,1] == ';'
          command << ' ' unless cmd[-1,1] == ' '
          list = []
          @tempfiles.each_with_index do |file, index| 
            list << "echo ${PIPESTATUS[#{index}]} > #{file.path}"
          end
          command + list.join(' & ')
        end
      end
    end
  end
end
