module EC2
  module Platform
    module Linux
      LOCAL_FS_TYPES = ['ext2', 'ext3', 'xfs', 'jfs', 'reiserfs', 'tmpfs']
      class Mtab
        class Entry
          REGEX = /^(\S+)\s+(\S+)\s+(\S+)\s+(\S+).*$/
          attr_reader :device   # mounted device.
          attr_reader :mpoint   # mount point.
          attr_reader :fstype   # file system type.
          attr_reader :options  # options
          attr_reader :value    # entire line
          
          
          def initialize(dev, mnt_point, fs_type, opts, line)
            @device = dev
            @mpoint = mnt_point
            @fstype = fs_type
            @options= opts
            @value  = line
          end
          
          def self.parse(line)
            return nil if line[0,1] == '#'
            if (m = REGEX.match(line))
              parts = m.captures
              return Entry.new(parts[0], parts[1], parts[2], parts[3], line.strip)
            else
              return nil
            end
          end
          
          def to_s
            value
          end
          
          def print
            puts(to_s)
          end
        end
        
        attr_reader :entries
        LOCATION = '/etc/mtab'
        
        def initialize(filename = LOCATION)
          begin
            f = File.new(filename, File::RDONLY)
          rescue SystemCallError => e
            raise FileError(filename, "could not open #{filename} to read mount table", e)
          end
          @entries = Hash.new
          f.readlines.each do |line|
            entry = Entry.parse(line)
            @entries[entry.mpoint] = entry unless entry.nil?
          end          
        end
        
        def self.load
          self.new()
        end
      end
    end
  end
end
