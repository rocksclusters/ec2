#!/usr/bin/env ruby

require 'ostruct'
require 'ec2/platform'

module EC2
  module Platform
    module Linux
      class Uname
        @@uname ||= OpenStruct.new
        def self.all
          @@uname.all ||= `uname -a`.strip
        end
        def self.platform
          @@uname.platform ||= `uname -i`.strip
        end
        def self.nodename
          @@uname.nodename ||= `uname -n`.strip
        end
        def self.processor
          @@uname.processor ||= `uname -p`.strip
        end
        def self.release
          @@uname.release ||= `uname -r`.strip
        end
        def self.os
          @@uname.os ||= `uname -s`.strip
        end
        def self.uname
          @@uname
        end        
      end
    end
  end
end
if __FILE__ == $0
   include EC2::Platform::Linux
   puts "Uname = #{Uname.all.inspect}"
end