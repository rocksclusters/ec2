module EC2
  module Platform
    module Linux; end
    EC2::Platform::PEER = EC2::Platform::Linux unless defined? EC2::Platform::PEER
  end
end