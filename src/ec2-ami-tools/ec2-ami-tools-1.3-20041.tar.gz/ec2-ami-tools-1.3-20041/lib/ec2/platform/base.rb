#------------------------------------------------------------------------------
module EC2
  module Platform
    module Base
      module Distribution
        UNKNOWN   = 'Unknown'
        GENERIC   = 'Generic'
      end
      class System
        MOUNT_POINT = '/mnt/img-mnt'
        def self.distribution
          Distribution::UNKNOWN
        end
        
        def self.superuser?
          false
        end
        
        def self.exec(cmd, debug)
          if debug
            puts( "Executing: #{cmd} " )
            suffix = ''
          else
            suffix = ' 2>&1 > /dev/null'
          end
          raise "execution failed: \"#{cmd}\"" unless system( cmd + suffix )
        end
      end
    end
  end
end