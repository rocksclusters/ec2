module EC2
  module Platform
    module Base
      class Architecture
        I386 = 'i386'
        X86_64 = 'x86_64'
        UNKNOWN = 'unknown'      
        SUPPORTED = [I386, X86_64]
        
        def self.supported? arch
          SUPPORTED.include? arch
        end
      end
    end
  end
end