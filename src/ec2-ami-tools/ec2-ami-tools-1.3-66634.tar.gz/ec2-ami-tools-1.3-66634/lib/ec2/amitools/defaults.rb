EC2_HOME = ENV['EC2_AMITOOL_HOME'] || ENV['EC2_HOME']
EC2_X509_CERT = "#{EC2_HOME}/etc/ec2/amitools/cert-ec2.pem"
